package am.android.example.android.filesviewer.finder.validation;

public interface TextColorProvider {
    int getBackgroundColor(String paintingString, String filter);
}
